# VSA Trader — GitHub Pages Handleiding

## Stap 1 — Maak een gratis GitHub account

1. Ga naar **[github.com](https://github.com)** en klik **Sign up**
2. Kies een gebruikersnaam (bv. `jouwNaam`) — dit wordt deel van je URL
3. Bevestig je e-mailadres

---

## Stap 2 — Maak een nieuwe repository aan

1. Klik op **+** (rechts bovenaan) → **New repository**
2. Vul in:
   - **Repository name:** `vsa-trader`
   - **Public** (verplicht voor gratis GitHub Pages)
   - ✅ Vink aan: **Add a README file**
3. Klik **Create repository**

---

## Stap 3 — Upload de bestanden

1. In je nieuwe repository, klik **Add file** → **Upload files**
2. Sleep `index.html` naar het uploadvenster
3. Klik **Commit changes**

---

## Stap 4 — Zet GitHub Pages aan

1. Ga naar je repository → **Settings** (tab bovenaan)
2. Klik in de linker zijbalk op **Pages**
3. Onder **Branch**: kies `main` en map `/root`
4. Klik **Save**
5. Wacht 1-2 minuten

---

## Stap 5 — Open je app

Je app is nu live op:
```
https://JOUWNAAM.github.io/vsa-trader/
```

Vervang `JOUWNAAM` met je GitHub gebruikersnaam.

Deel deze link met je dochter — ze kan de app gewoon openen in de browser, geen installatie nodig.

---

## App bijwerken

Wanneer je een nieuwe versie van `index.html` hebt:
1. Ga naar je repository op GitHub
2. Klik op `index.html`
3. Klik het potloodje (✏️ Edit)
4. Of klik **Add file** → **Upload files** en upload de nieuwe versie

---

## Problemen?

- **App laadt niet:** Wacht 5 minuten na het aanzetten van GitHub Pages
- **Data werkt niet:** Controleer je internetverbinding — de app haalt data op van Yahoo Finance
- **Symbool niet gevonden:** Controleer het symbool op [finance.yahoo.com](https://finance.yahoo.com)
  - US stocks: `AAPL`, `TSLA`, `NFLX`
  - AEX stocks: `ASML.AS`, `PHIA.AS`, `HEIA.AS`
  - ETFs: `SPY`, `QQQ`, `SOXL`

---

*VSA Trader — gratis, open source, geen API key nodig*
